---
title: "Failure-Aware Change Management Framework"
subtitle: "Detecting, Controlling, and Correcting Failure Before It Scales"
author: "MKD"
date: "2026-04-17"
---

# Failure-Aware Change Management Framework

## Detecting, Controlling, and Correcting Failure Before It Scales

- A practical control framework for Healthcare IT change
- Built for clinical workflow, data integrity, and operational continuity
- Focused on what must be detected before harm spreads

<div class="notes">This presentation introduces the Failure-Aware Change Management Framework. The focus is practical: How Healthcare IT leaders detect failure early, control the failure path, and implement corrective action before clinical workflow, data integrity, operational continuity, or trust are damaged. The starting point is deliberately blunt because the operating environment is blunt.</div>

---

## Core Statement

- **Change Management is Failure Management.**
- **Core Statement:** Change management identifies failure early, controls the failure path, and implements corrective action before harm spreads.

<div class="notes">In this session, I want to reframe change management for the environment Healthcare IT actually operates in. Not the sanitized version of change management where the communication plan lands cleanly, training completion means readiness, and the go-live dashboard tells the full truth. Put bluntly, Change Management is Failure Management. The Core Statement gives that claim its operating discipline: Change management is the discipline of identifying failure early, taking control of the failure path, and implementing corrective action before harm spreads across clinical workflow, data integrity, operational continuity, or trust.</div>

---

## Foundational Reframe

| Traditional View | Control-Oriented View |
|:---|:---|
| Adoption is achievable | Failure is the default |
| Resistance is the exception | Success is engineered |
| Plans hold with communication | Plans are tested by reality |
| Status reporting detects trouble | Control must be engineered |

<div class="notes">Traditional change models often begin with a comforting assumption: If we communicate well enough, train enough people, and monitor the project plan, adoption will follow. That assumption is thin in a hospital, where the system touches clinical judgment, unit routines, order flows, identity matching, results visibility, and patient safety. A better starting point is this: Failure is the default condition of meaningful change, and success has to be engineered through deliberate controls, not hoped into existence by communication volume.</div>

---

## The Silent Failure Problem

- Missed deadlines and outages make noise
- Disengaged champions often do not
- Incorrect data can move through green interfaces
- Paper compliance can hide operational failure
- Passive detection is unmanaged failure dressed as governance

<div class="notes">Healthcare IT teams are used to visible failure: A system goes down, an interface queue backs up, a milestone slips, or a support ticket storm begins. The more dangerous failures are often quieter. A clinical champion stops defending the change. A department complies publicly and works around privately. An interface stays green while the operational meaning of the data is wrong. If our governance model waits for noise, it will miss the early signal and arrive after the risk has already entered the workflow.</div>

---

## The Skipped Planning Question

- **Question:** How will we know something is going wrong before it becomes a crisis?
- It is skipped because it makes optimism accountable
- It forces evidence before the post-mortem
- It assigns control owners before failure becomes political
- It turns discomfort into executable discipline

<div class="notes">The most important planning question is usually the one teams avoid: How will we know something is going wrong before it becomes a crisis? It is uncomfortable because it forces the team to define evidence that the project may not be working. But in Healthcare IT, that discomfort is a control requirement. Before go-live pressure arrives, leaders need to know what signal matters, who owns it, what threshold activates intervention, and what decision can be made without waiting for perfect certainty.</div>

---

## The Operating Assumption

**Failure Is Not an Exception; It Is the Default Condition of Change**

- Every meaningful change creates misalignment
- Every workflow redesign creates friction
- Every system transition creates breakdown risk
- The discipline is not avoiding failure; it is detecting and controlling it early

<div class="notes">Failure is not an exception; it is the default condition of change. That does not mean every initiative is doomed. It means every meaningful change creates misalignment, friction, and breakdown risk as soon as it touches real people, real workflows, and real systems. The mature response is not denial or optimism dressed up as governance. The mature response is early detection, active control, and corrective action before the failure path becomes operational reality.</div>

---

## Governing Principles

- **Assume Failure Will Appear Before It Announces Itself**
- **Detection Must Be Actively Designed**
- **Control Comes Before Scale**
- **Failure Must Trigger Intervention**
- **Corrective Action Must Be Implemented**
- **Accountability Must Cross People, Process, and Technology**

<div class="notes">These six Governing Principles convert the Core Statement into execution discipline. First, assume failure will appear, because it will. Second, design detection instead of depending on passive reporting. Third, control failure before expanding the rollout. Fourth, treat failure as a signal stream that triggers intervention, not as an outcome discovered at the end. A meaningful signal should activate a predefined decision. Fifth, implement corrective action, not merely lessons learned. Sixth, diagnose across people, process, and technology because the real failure rarely respects your workstream boundaries.</div>

---

## How to Use the Framework

1. Identify the different elements of the PPT overlay in the project.
2. Ask the six control questions for each material element.
3. Implement changes to the Project Implementation Plan.

<div class="notes">The framework is not a philosophy exercise. It is a work instruction. First, identify the elements of the PPT overlay in the project. Second, ask the six control questions against each material element. Third, convert the answers into changes to the Project Implementation Plan. If the output does not change preventive measures, detection mechanisms, or response mechanisms, the team has discussed risk but has not managed failure.</div>

---

## Step 1: Map the PPT Overlay

| Discussion Order | Why It Comes Here |
|:---|:---|
| Technology | Easiest to inspect, monitor, and control |
| Process | Easiest to underestimate because real work is messy |
| People | Hardest to control because behavior is political and social |
| Integrator | Owns failure that crosses domain boundaries |

<div class="notes">For this presentation, we reverse the usual people-process-technology discussion. Technology comes first because it is the easiest to inspect and manage. Process comes second because it is the easiest to underestimate; the workflow on paper is rarely the workflow on the floor. People comes last because it is the most challenging. Human behavior carries incentives, authority, trust, fatigue, politics, and informal power. The integrator layer is what prevents these domains from becoming separate excuses.</div>

---

## Step 2: Ask the Six Questions

| Diagnostic Area | Operating Question |
|:---|:---|
| Identify Success Criteria | What does success look like for this? |
| Assumptions | What things are we thinking should be in place, and what are given? |
| Identifying Risk | Where do we expect to fail? What will fail? |
| Detection | How do we first detect it? How do we know? |
| Prevention | What do we need to do now to avoid that? |
| Respond | What do we need to do when that happens? |

<div class="notes">These six questions should be applied at multiple levels: The project, the workstream, the unit, the workflow, the interface, the role, and the system function. The first three questions define intent and vulnerability. The last three questions define operational control: How we detect the failure, what we do now to reduce exposure, and what action we execute when the signal appears. If the answers do not change the implementation plan, the exercise is decorative.</div>

---

## Step 3: Change the Implementation Plan

| Framework Output | Project Implementation Plan Change |
|:---|:---|
| Expected failure | Preventive Measures |
| Weak signal | Detection Mechanisms |
| Trigger threshold | Response Mechanisms |
| Cross-domain risk | Named decision owner |
| Clinical exposure | Escalation and fallback path |

<div class="notes">This is where the framework becomes real. The team does not stop after identifying risks. Expected failure becomes a preventive measure. A weak signal becomes a detection mechanism. A trigger threshold becomes a response mechanism. Cross-domain risk gets a named decision owner. Clinical exposure gets an escalation and fallback path. That is the difference between risk documentation and failure management.</div>

---

## Example: Radiology Workflow Control Questions

| Area | Radiology Control Answer |
|:---|:---|
| Identify Success Criteria | Imaging orders, images, and reports move safely across RIS, PACS, and EHR |
| Assumptions | Orders, modality worklists, accession numbers, images, and reports stay synchronized |
| Identifying Risk | Wrong exam context, missing images, delayed reads, or report delivery gaps |
| Detection | Worklist mismatches, unsigned report backlog, PACS complaints, missing-result calls |
| Prevention | Validate ORM, DICOM Modality Worklist, image routing, and report interfaces |
| Respond | Pause expansion, reconcile studies, fix mappings, activate manual result escalation |

<div class="notes">Take a Radiology workflow change: A RIS replacement, PACS migration, reporting upgrade, or EHR imaging integration. The success criterion is not simply that the interface is live or that images can be opened. The success criterion is that the right exam is ordered, scheduled, performed, interpreted, signed, and delivered to the right clinical context without breaking patient identity, accession linkage, image availability, or report visibility. Prevention means validating ORM messages, DICOM Modality Worklist behavior, image routing, accession mapping, and report interfaces before expansion pressure takes over. If we see worklist mismatches, unsigned report backlog, missing images, or repeated calls for results, that signal should not trigger generic retraining by default. It should trigger a controlled decision: Pause expansion if needed, reconcile affected studies, fix mappings, and activate manual result escalation until the failure path is controlled.</div>

---

## Technology Failure

- **Core Risk:** The tool works technically but fails operationally
- Interface transport can succeed while clinical meaning fails
- Green dashboards can hide semantic failure
- Wrong information creates patient-safety risk
- Detection must combine logs, users, workflow, and data validation

<div class="notes">Technology comes first because it is usually the easiest domain to inspect. Healthcare IT teams can check interfaces, logs, latency, access, device availability, build configuration, and data movement. But technical manageability does not mean low risk. Transport success is not semantic success. An HL7 ACK or a successful DICOM send proves movement behavior, not necessarily clinical correctness. The system can be online, the interface can be green, and the vendor can report normal operation while the clinical workflow is failing. Wrong information is the highest-risk category because it carries a false sense of safety.</div>

---

## Process Failure

- **Core Risk:** Designed workflow does not match real work
- Current-State Error: The future state is built on a false baseline
- Shadow Workflow: Workarounds expose missing steps or unsafe timing
- Stuck Between Old and New: Hybrid operations become permanent
- Control Task: Classify, control, and redesign broken workflow

<div class="notes">Process comes second because it is the easiest domain to underestimate. The official process map often omits informal coordination, shift patterns, physical constraints, exception handling, and the small improvisations that keep patient care moving. Shadow workflow is not automatically the enemy. Sometimes it is unsafe behavior and has to be stopped. Sometimes it is necessary compensation for a bad design. A future-state workflow built on a false baseline may look elegant in a workshop and collapse on the floor. The most dangerous outcome is the hybrid state, where old and new processes run together until the workaround becomes the real operating model.</div>

---

## People Failure

- **Core Risk:** Superficial agreement is mistaken for adoption
- Attendance proves exposure, not competence
- Quiet champions are a political signal
- Influential Opponent: Informal authority works against change
- Owner in Name Only: Accountability exists only on paper
- Workarounds often reveal the truth first

<div class="notes">People comes last because it is the hardest domain to control. People failure is not just resistance. It is the gap between formal agreement and actual behavior. Attendance is not adoption, and training completion is not competence. In clinical environments, adoption is proven by behavior under pressure, especially during busy shifts, handoffs, interruptions, and exception cases. Healthcare organizations have strong informal authority structures: Senior physicians, charge nurses, unit managers, respected analysts, and operational fixers can make or break adoption without ever appearing as formal decision-makers. When a physician champion becomes quiet, treat that as a political and operational signal.</div>

---

## The Integrator Layer

- Real breakdown is controlled between domains
- Technology defects get mislabeled as adoption problems
- Process gaps get patched with manual work
- People resistance exposes workflow flaws
- Clean interfaces can still create unsafe behavior when workflow meaning fails

<div class="notes">The integrator layer exists because the real breakdown often lives between domains. A technology problem gets mislabeled as user resistance. A process defect gets hidden by manual work. People resistance exposes a workflow flaw leadership preferred not to see. A technically clean interface creates unsafe behavior because the receiving workflow is wrong. This is where organizations solve the wrong problem with impressive discipline. If nobody owns cross-domain diagnosis, the failure path stays intact.</div>

---

## Failure Management Dashboard

| Layer | Purpose |
|:---|:---|
| Executive Snapshot | Force current leadership decisions |
| Failure Register | Track signals, control action, owner, and status |
| Decision Log | Record stop, change, accept, and defer choices |
| Review Cadence | Match frequency to clinical and operational risk |

<div class="notes">The dashboard is not a status report. A status report tells leaders what happened or what percentage is complete. A failure management dashboard tells leaders what needs control now. The executive snapshot should identify active failures, failure velocity, critical path exposure, and the decision required this cycle. If it does not force a stop, change, accept, defer, or implement decision, it is not governing the implementation.</div>

---

## Example Failure Register Entry

| Field | Example |
|:---|:---|
| Failure Signal | DICOM send success with rising missing-image complaints |
| Scope | ED night shift, CT studies, PACS viewer and EHR imaging link |
| Threshold | More than 3 verified complaints in 4 hours |
| Control Owner | PACS administrator and ED clinical operations lead |
| Decision Required | Hold expansion, reconcile studies, validate routing, activate manual image access |

<div class="notes">This is the level of specificity that makes the register useful. The signal is not just that users are unhappy. The signal is DICOM send success with rising missing-image complaints in a defined scope. The threshold tells the team when governance must act. The owner pairing keeps the PACS and clinical operations sides in the same decision loop. The decision required is explicit, so the register becomes a control instrument rather than a parking lot for issues.</div>

---

## Apply It to One Active Initiative

- **Discussion Prompt:** Where is your current change portfolio most likely to confuse silence with stability?
- **Next Step:** Select one active initiative and build its control dashboard
- **Immediate Work:** Define signals, owners, thresholds, and fallback paths
- **Operating Standard:** Protect continuity, safety, trust, and decision quality

<div class="notes">Apply the framework to one active initiative, not the entire portfolio. Pick the project where silence is most likely being mistaken for stability. Build the control dashboard, define the signals, authorize the owners, set the thresholds, and decide what intervention happens when the evidence appears. Silence is not stability. Compliance is not adoption. Availability is not operational success. That is where this framework becomes useful: Not as a theory of change, but as a control discipline for the work that must survive contact with clinical reality.</div>
