# Project Manager Mindset Source Material

## Purpose

This source material arms the project manager with the operating mindset behind the Failure-Aware Change Management Framework.

The framework gives structure. The project manager gives it force.

Without the right mindset, the framework will degrade into another dashboard, another risk register, another polite meeting where everyone reports green until reality breaks through the floor.

The project manager's job is not to keep the plan looking stable.

The project manager's job is to keep the change honest.

## The PM's First Obligation

The first obligation of the project manager is not optimism. It is detection.

Optimism is cheap. It is easy to say the workstream is on track when nobody has looked hard enough for the signals that prove otherwise.

Detection is harder. Detection requires asking uncomfortable questions while there is still time to do something useful with the answer.

The disciplined project manager does not ask, "Are we on track?"

That question is too weak. It invites reassurance.

The better questions are:

- Where is the plan already wrong?
- What are we pretending is stable?
- Who has gone quiet?
- What workaround has become normal?
- What signal would prove this rollout is starting to fail?
- What would we see first if adoption were performative?
- What would we see first if the workflow were unsafe?
- What would we see first if the system were technically live but operationally useless?

The project manager is not the clerk of the project plan. The project manager is the early-warning system.

## The Core Statement in PM Language

The Core Statement says:

> Change management is the systematic identification, containment, and adaptation to failure across people, process, and technology before it compounds into irreversible loss.

For the project manager, this means:

- Identify failure before it becomes politically expensive to admit.
- Contain failure before it spreads across teams, departments, sites, or systems.
- Adapt the plan before the plan becomes a liability.
- Protect the work, not the appearance of control.

The plan is a hypothesis.

The frontline is the test environment.

The dashboard is only useful if it changes decisions.

## The Dangerous Lie of Green Status

Green status is not evidence.

Green status often means only that no one has escalated loudly enough yet.

In weak projects, green means:

- The meeting happened.
- The milestone was not formally missed.
- The vendor said the interface is ready.
- Training attendance was high.
- No executive has complained.
- The report template has no place for the real issue.

None of that proves readiness.

In failure-aware change management, green must mean:

- The critical assumptions are still true.
- Detection signals are being actively monitored.
- The people who matter are still engaged.
- The process works under real operating conditions.
- The technology is producing reliable information.
- Workarounds are known, contained, and governed.
- The next failure point has an owner and a response path.

If green status cannot survive questioning, it is not status. It is theater.

## The PM's Operating Posture

The project manager must carry five postures into every change cycle.

### 1. Assume the Plan Is Incomplete

The plan is necessary, but it is not reality.

Every implementation plan is built from incomplete knowledge, partial stakeholder truth, idealized process maps, vendor assumptions, and optimistic sequencing.

That does not make the plan useless. It makes it provisional.

The project manager must treat the plan as something to test, not something to defend.

### 2. Treat Silence as a Signal

Silence is not alignment.

Silence may mean:

- People are confused.
- People are waiting for the change to fail.
- People do not trust the room.
- People have already built a workaround.
- People are complying publicly and resisting privately.
- People know the process is broken but no longer believe escalation works.

The quietest part of the project may be the part closest to failure.

### 3. Chase Weak Signals Before Strong Ones

By the time the signal is strong, the cost has already increased.

A missed milestone is late evidence.

A spike in defects is late evidence.

A formal complaint is late evidence.

A failed go-live is late evidence.

The project manager must look for earlier signals:

- Repeated clarification questions.
- Drift in meeting attendance.
- Informal side conversations.
- Small increases in exception handling.
- Managers using different explanations.
- Staff saying "we will figure it out later."
- Manual reconciliation becoming normal.
- Support tickets clustering around one workflow.

Weak signals are where the leverage is.

### 4. Separate Adoption From Compliance

Compliance is easy to fake.

Adoption is harder.

A team can attend training, sign acknowledgment forms, use the system when watched, and still avoid the change when real work begins.

The project manager must not confuse:

- Attendance with understanding.
- Understanding with belief.
- Belief with behavior.
- Behavior under observation with behavior under pressure.
- System login with useful system use.
- Process compliance with better outcomes.

Adoption is proven when the new way survives workload, interruption, fatigue, staffing variation, and local pressure.

### 5. Protect the Critical Path From Political Comfort

The critical path is not only technical.

It also runs through trust, decision rights, workflow legitimacy, data reliability, and frontline credibility.

The project manager must be willing to make discomfort visible when silence would protect the room but damage the project.

That means naming:

- The owner who is not owning.
- The champion who is withdrawing.
- The process that works only in workshops.
- The vendor answer that does not match operational reality.
- The training metric that hides non-adoption.
- The integration that is technically passing but clinically suspect.

Political comfort is not a deliverable.

## The PM's Mental Model

The project manager is managing a live system with four layers.

### People

People fail through misalignment, resistance, silence, confusion, fatigue, weak ownership, and informal influence structures.

The PM question:

> Who must believe, decide, reinforce, or change behavior for this to work - and what evidence proves they are actually doing it?

### Process

Process fails when the designed flow does not match how work actually gets done.

The PM question:

> Where does the future-state process collide with real workload, handoffs, interruptions, exceptions, and local practice?

### Technology

Technology fails when it is unstable, inaccessible, unusable, poorly integrated, or semantically unreliable.

The PM question:

> Where could the system appear live while still producing unsafe, incorrect, delayed, or operationally useless information?

### Integrator Layer

The integrator layer fails when the project diagnoses the wrong problem.

The PM question:

> Are we calling this a people problem because we do not want to admit the process or technology is broken?

## The Questions the PM Must Keep Asking

These are not ceremonial questions. They are control questions.

### Success Criteria

- What does success look like in observable behavior?
- What does success look like under pressure?
- What would prove this is working beyond attendance, completion, or go-live?

### Assumptions

- What must be true for this plan to work?
- Which assumptions are untested?
- Which assumptions are inherited from vendor material, leadership optimism, or outdated process maps?

### Expected Failure

- Where do we expect failure first?
- Which failure would be most expensive if detected late?
- Which failure would people be most tempted to hide?

### Detection

- What is the first weak signal?
- Who is responsible for watching it?
- How often is it reviewed?
- What threshold forces action?

### Prevention

- What can we do now to reduce the probability of failure?
- What fallback must be ready before rollout?
- What ownership gap must be closed before scale?

### Response

- What happens when the signal appears?
- Who decides?
- What gets paused, contained, escalated, or redesigned?
- What will we not allow to spread?

## Meeting Discipline

The project manager must change the meeting culture.

Most project meetings are designed to collect updates. That is not enough.

Failure-aware meetings are designed to expose risk, force decisions, and update the plan.

### Weak Meeting Question

> Are there any issues?

This question produces silence.

### Strong Meeting Questions

- What changed since the last review that makes our assumptions weaker?
- What is getting harder but has not yet become an issue?
- What are frontline users doing that is different from the designed process?
- What has gone quiet?
- What are we solving manually that the future state was supposed to solve structurally?
- What is green on the dashboard but questionable in practice?
- What decision are we avoiding?

If the meeting produces no decision, no containment action, no assumption update, and no change to the implementation plan, it was probably a reporting ritual.

## Dashboard Discipline

The dashboard must not become decoration.

A useful dashboard changes behavior. It forces attention to the failures that can damage adoption, safety, continuity, or trust.

The project manager should treat every dashboard cycle as a decision cycle:

- What failure is emerging?
- What signal proves it?
- What domain does it belong to?
- What other domain is it affecting?
- What are we containing now?
- What are we adapting next?
- Who owns the action?
- What decision is required from leadership?

The dashboard should make denial harder.

## Language That Creates Accountability

The project manager needs language that cuts through vague reassurance.

Use:

- "What evidence supports that?"
- "What would we see if that were not true?"
- "Who owns the next action?"
- "What is the containment plan?"
- "What is the fallback?"
- "What signal would trigger escalation?"
- "Is this a people issue, a process issue, a technology issue, or an interaction issue?"
- "Are we solving the cause or absorbing the pain?"
- "Are we delaying because we need evidence or because the decision is uncomfortable?"
- "If this fails during go-live, what will we wish we had done this week?"

Avoid:

- "Hopefully."
- "Should be fine."
- "Users just need to adopt."
- "Training will fix it."
- "The vendor says it is ready."
- "We will monitor it."
- "There are no issues."
- "We can handle that later."

Those phrases are usually where unmanaged failure hides.

## The PM's Non-Negotiables

The project manager must insist on these conditions:

- Every critical assumption has an owner.
- Every high-risk workflow has a detection signal.
- Every unresolved failure has a containment action.
- Every workaround is visible and governed.
- Every critical dependency has an escalation path.
- Every major decision has a named decision-maker.
- Every green status can be defended with evidence.
- Every go-live risk has a response plan.
- Every people, process, and technology issue is checked against the integrator layer.

If these conditions are absent, the project is not being managed. It is being narrated.

## What the PM Must Notice First

The project manager should pay special attention to:

- Supportive stakeholders becoming passive.
- Owners attending meetings but not taking action.
- Champions becoming quieter as rollout approaches.
- Training attendance looking strong while questions remain repetitive.
- Managers explaining the change differently.
- Teams creating local versions of the process.
- Manual reconciliation becoming routine.
- Workarounds spreading from one unit to another.
- Vendor confidence rising while frontline confidence falls.
- Technical status staying green while operational trust declines.
- Escalations becoming more frequent but less specific.

These are not soft signals. These are implementation vitals.

## The PM's Bias for Action

Failure-aware change management does not require panic. It requires disciplined response.

When a signal appears:

1. Name it.
2. Classify it.
3. Find the owner.
4. Contain the spread.
5. Test the assumption.
6. Decide what changes.
7. Update the plan.
8. Watch for recurrence.

Do not wait for certainty when the cost of waiting is higher than the cost of controlled action.

## The Mindset Shift

The old project management mindset says:

> Keep the plan on track.

The failure-aware mindset says:

> Keep reality visible enough that the plan can survive contact with it.

The old mindset asks:

> Did we complete the activity?

The failure-aware mindset asks:

> Did the activity reduce the risk of failure?

The old mindset asks:

> Did users attend training?

The failure-aware mindset asks:

> Can users perform the work correctly under real conditions?

The old mindset asks:

> Is the system live?

The failure-aware mindset asks:

> Is the system trusted, usable, and producing information safe enough to act on?

The old mindset asks:

> Are there any issues?

The failure-aware mindset asks:

> What failure is trying to become visible?

## Final Charge to the Project Manager

Your job is not to be the guardian of the schedule.

Your job is to be the guardian of operational truth.

The schedule matters. The budget matters. The governance deck matters. But none of them matter more than the actual condition of the change as it moves through people, process, technology, and their interactions.

Do not be satisfied because the room is calm.

Do not be reassured because the dashboard is green.

Do not confuse politeness with alignment.

Do not confuse attendance with adoption.

Do not confuse system availability with safe operational use.

Do not confuse a signed-off plan with a survivable implementation.

Failure is already present somewhere in the system. The project manager's discipline is to find it early, contain it fast, and force the organization to adapt before the cost becomes irreversible.
