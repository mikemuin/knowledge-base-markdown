---
title: "Failure-Aware Change Management Framework"
subtitle: "Detecting, Controlling, and Correcting Failure Before It Scales"
author: "MKD"
date: "2026-04-17"
---

# Failure-Aware Change Management Framework

- **Change Management is Failure Management.**
- **Core Statement:** Change management identifies failure early, controls the failure path, and implements corrective action before harm spreads.

<div class="notes">In this session, I want to reframe change management for the environment Healthcare IT actually operates in. Not the sanitized version of change management where the communication plan lands cleanly, training completion means readiness, and the go-live dashboard tells the full truth. Put bluntly, Change Management is Failure Management. The Core Statement gives that claim its operating discipline: Change management is the discipline of identifying failure early, taking control of the failure path, and implementing corrective action before harm spreads across clinical workflow, data integrity, operational continuity, or trust.</div>

---

## Foundational Reframe

| Traditional View | Control-Oriented View |
|:---|:---|
| Adoption is achievable | Failure is the default |
| Resistance is the exception | Success is engineered |
| Plans hold with communication | Plans are tested by reality |
| Status reporting detects trouble | Control must be engineered |

<div class="notes">Traditional change models often begin with a comforting assumption: If we communicate well enough, train enough people, and monitor the project plan, adoption will follow. That assumption is thin in a hospital, where the system touches clinical judgment, unit routines, order flows, identity matching, results visibility, and patient safety. A better starting point is this: Failure is the default condition of meaningful change, and success has to be engineered through deliberate controls, not hoped into existence by communication volume.</div>

---

## The Silent Failure Problem

- Missed deadlines and outages make noise
- Disengaged champions often do not
- Incorrect data can move through green interfaces
- Paper compliance can hide operational failure
- Passive detection is unmanaged failure dressed as governance

<div class="notes">Healthcare IT teams are used to visible failure: A system goes down, an interface queue backs up, a milestone slips, or a support ticket storm begins. The more dangerous failures are often quieter. A clinical champion stops defending the change. A department complies publicly and works around privately. An interface stays green while the operational meaning of the data is wrong. If our governance model waits for noise, it will miss the early signal and arrive after the risk has already entered the workflow.</div>

---

## Silent Failures in Healthcare IT

- HL7 interface is green, but OBX values map incorrectly
- ADT feed is timely, but patient matching degrades
- Nurses document after care because workflow timing is wrong
- Clinical champion attends meetings but stops defending the change
- Training completion is high while workarounds spread by shift

<div class="notes">These examples are not theoretical. An HL7 feed can acknowledge messages while the wrong observation values are landing in the wrong operational context. An ADT stream can be timely while the patient identity layer slowly degrades through duplicate records, overlays, or weak matching logic. Nurses may complete documentation, but if it happens after care because the workflow does not fit the bedside reality, the implementation is carrying clinical and legal risk. The core lesson is that system availability, message transport, and training completion are not the same thing as safe adoption.</div>

---

## The Skipped Planning Question

- **Question:** How will we know something is going wrong before it becomes a crisis?
- It is skipped because it makes optimism accountable
- It forces evidence before the post-mortem
- It assigns control owners before failure becomes political
- It turns discomfort into executable discipline

<div class="notes">The most important planning question is usually the one teams avoid: How will we know something is going wrong before it becomes a crisis? It is uncomfortable because it forces the team to define evidence that the project may not be working. But in Healthcare IT, that discomfort is a control requirement. Before go-live pressure arrives, leaders need to know what signal matters, who owns it, what threshold activates intervention, and what decision can be made without waiting for perfect certainty.</div>

---

## From Risk Register to Intervention Design

| Weak Artifact | Strong Intervention Design |
|:---|:---|
| Risk listed | Signal defined |
| Owner named | Owner authorized |
| Mitigation noted | Trigger threshold set |
| Escalation documented | Decision rights confirmed |
| Review scheduled | Intervention cadence active |

<div class="notes">A risk register is not a control system. It may satisfy a governance ritual, but it does not necessarily change what happens at two in the morning when a unit cannot complete the work safely. Intervention design is different. It defines the signal, authorizes the owner, sets the trigger threshold, confirms decision rights, and establishes the cadence for action. For Healthcare IT professionals, this is where project management becomes operationally meaningful.</div>

---

## The Operating Assumption

**Failure Is Not an Exception; It Is the Default Condition of Change**

- Every meaningful change creates misalignment
- Every workflow redesign creates friction
- Every system transition creates breakdown risk
- The discipline is not avoiding failure; it is detecting and controlling it early

<div class="notes">Failure is not an exception; it is the default condition of change. That does not mean every initiative is doomed. It means every meaningful change creates misalignment, friction, and breakdown risk as soon as it touches real people, real workflows, and real systems. The mature response is not denial or optimism dressed up as governance. The mature response is early detection, active control, and corrective action before the failure path becomes operational reality.</div>

---

## Governing Principles

- **Assume Failure Will Appear Before It Announces Itself**
- **Detection Must Be Actively Designed**
- **Control Comes Before Scale**
- **Corrective Action Must Be Implemented**
- **Accountability Must Cross People, Process, and Technology**

<div class="notes">These five Governing Principles convert the Core Statement into execution discipline. First, assume failure will appear, because it will. Second, design detection instead of depending on passive reporting. Third, control failure before expanding the rollout. Fourth, implement corrective action, not merely lessons learned. Fifth, diagnose across people, process, and technology because the real failure rarely respects your workstream boundaries.</div>

---

## Failure as an Intervention Loop

- **Old Definition:** Failure is an outcome discovered at the end
- **New Definition:** Failure is a signal that triggers intervention
- Signals activate predefined decisions
- Deviations change the workplan
- System inconsistencies force correction

<div class="notes">The practical shift is to stop treating failure as an end-state label and start treating it as an intervention loop. A meaningful signal should activate a predefined decision. A deviation should change the workplan. A system inconsistency should force correction before it becomes normalized as workaround labor. This is not pessimism; it is how mature implementation teams keep clinical operations safe while change is still moving.</div>

---

## Six Control Questions

| Diagnostic Area | Operating Question |
|:---|:---|
| Success Criteria | What does success look like? |
| Assumptions | What must be true? |
| Identifying Risk | Where do we expect failure? |
| Detection | How will we first know? |
| Prevention | What must we do now? |
| Control Response | What action do we execute? |

<div class="notes">These six control questions should be applied at multiple levels: The project, the workstream, the unit, the workflow, the interface, the role, and the system function. The first three questions define intent and vulnerability. The last three questions define operational control: How we detect the failure, what we do now to reduce exposure, and what action we execute when the signal appears. If the answers do not change the implementation plan, the exercise is decorative.</div>

---

## Example: CPOE Rollout Control Questions

| Area | CPOE Control Answer |
|:---|:---|
| Success Criteria | Orders entered safely at point of care |
| Assumptions | Providers trust access, order sets, and timing |
| Identifying Risk | Unsafe workarounds or delayed order entry |
| Detection | Order delays, overrides, tickets, paper fallback |
| Prevention | Validate order sets, access, devices, and point-of-care workflow |
| Control Response | Pause expansion, fix workflow, retrain targeted users |

<div class="notes">Take a CPOE rollout. The success criterion is not simply that the module is live or that providers attended training. The success criterion is that orders are entered safely at the point of care, with the right timing, order sets, clinical context, and trust. Prevention means validating order sets, access, devices, and point-of-care workflow before expansion pressure takes over. If we see delayed orders, unsafe overrides, clustered tickets, or paper fallback, that signal should not trigger generic retraining by default. It should trigger a controlled decision: Pause expansion if needed, fix the workflow, validate order sets, and target retraining only after the design problem is understood.</div>

---

## PPT Failure Overlay

| Domain | Primary Failure Question |
|:---|:---|
| People | Are alignment and behavior real? |
| Process | Does the workflow survive reality? |
| Technology | Does the system support safe work? |
| Integrator | Who controls cross-domain failure? |

<div class="notes">The people, process, and technology overlay is familiar, but it is often used too superficially. In this framework, each domain is a failure origin, not just a planning category. People asks whether alignment is real. Process asks whether the workflow survives actual workload, interruptions, staffing, and physical movement. Technology asks whether the system supports safe work, not merely whether it is available. The integrator asks who controls failure when the cause crosses boundaries.</div>

---

## People Failure

- **Core Risk:** Superficial agreement is mistaken for adoption
- Flying Blind: Stakeholder power is unmapped
- Influential Opponent: Informal authority works against change
- Owner in Name Only: Accountability exists only on paper
- Stale Situation: The room has changed and the map has not

<div class="notes">People failure is not just resistance. It is the gap between formal agreement and actual behavior. Healthcare organizations have strong informal authority structures: Senior physicians, charge nurses, unit managers, respected analysts, and operational fixers can make or break adoption without ever appearing as formal decision-makers. If stakeholder power is unmapped, if an influential opponent is shaping the hallway narrative, or if the named owner is inactive, the implementation is flying blind.</div>

---

## Clinical Adoption Is Not Attendance

- Attendance proves exposure, not belief
- Training completion proves access, not competence
- Quiet physician champions may signal political risk
- Nurse workarounds often expose workflow truth first
- Unit managers translate change better than central teams

<div class="notes">Attendance is not adoption. Training completion is not competence. In clinical environments, adoption is proven by behavior under pressure, especially during busy shifts, handoffs, interruptions, and exception cases. When a physician champion becomes quiet, treat that as a political and operational signal. When nurses create workarounds, do not automatically label it resistance. Very often, the workaround is the first honest diagnostic report on whether the workflow fits the care setting.</div>

---

## Process Failure

- **Core Risk:** Designed workflow does not match real work
- Current-State Error: The future state is built on a false baseline
- Ideal Conditions: The process collapses under workload
- Stuck Between Old and New: Hybrid operations become permanent
- Compliance Without Improvement: Activity rises while outcomes stay flat

<div class="notes">Process failure usually begins with a false picture of current state. The official process map omits informal coordination, shift patterns, physical constraints, exception handling, and the small improvisations that keep patient care moving. A future-state workflow built on that false baseline may look elegant in a workshop and collapse on the floor. The most dangerous outcome is the hybrid state, where old and new processes run together until the workaround becomes the real operating model.</div>

---

## Shadow Workflow Is a Diagnostic Signal

- Workarounds are not always resistance
- They expose missing steps, unsafe timing, or poor usability
- Suppressing workarounds can hide the real failure path
- The task is to classify, control, and redesign them
- Permanent shadow work means implementation has lost authority

<div class="notes">Shadow workflow is not automatically the enemy. Sometimes it is unsafe behavior and has to be stopped. Sometimes it is necessary compensation for a bad design. Sometimes it is the only visible evidence that the implementation has broken the timing, sequence, or usability of real work. The discipline is to classify the workaround, control the risk, and redesign the workflow. If shadow work becomes permanent, the implementation has lost authority no matter what the compliance report says.</div>

---

## Technology Failure

- **Core Risk:** The tool works technically but fails operationally
- Wrong System Selected: The platform does not fit the work
- Access Failure: Staff cannot use it where work happens
- Wrong Information: Green systems produce unsafe data
- Non-Use: Staff finish work outside the system

<div class="notes">Technology failure in Healthcare IT is not limited to downtime. The system can be online, the interface can be green, and the vendor can report normal operation while the clinical workflow is failing. Wrong information is the highest-risk category because it carries a false sense of safety. If the system produces delayed, incomplete, duplicated, or incorrectly mapped information, the decision-maker may trust the screen while the underlying data is clinically unreliable.</div>

---

## Technology Failure Is Not Just Downtime

- Interface transport can succeed while clinical meaning fails
- Message acceptance does not prove workflow completion
- Data latency can be clinically material before severity rises
- Duplicate or mismatched records create downstream decision risk
- Green dashboards can hide semantic failure

<div class="notes">Healthcare IT professionals know this problem well: Transport success is not semantic success. An HL7 ACK proves receipt behavior, not necessarily clinical correctness. A message can pass, a dashboard can stay green, and still the result may arrive too late, map to the wrong field, land under the wrong patient, or fail to support the receiving workflow. That is why interface monitoring must be paired with semantic validation and operational observation.</div>

---

## High-Risk Technology Signals

| Signal | What It May Mean |
|:---|:---|
| ACK success with user complaints | Technical success, operational failure |
| Rising manual reconciliation | Integration trust is breaking |
| Duplicate MRNs or overlays | Identity control is failing |
| Delayed results visibility | Clinical timing is compromised |
| Increased overrides | Workflow or CDS is misaligned |

<div class="notes">These signals should never be treated as background noise. ACK success with user complaints means the technical layer and the operational layer are telling different stories. Rising manual reconciliation means users no longer trust the integrated flow. Duplicate MRNs or overlays mean identity control is failing, and that can poison downstream decisions. Increased overrides may indicate alert fatigue, bad decision-support logic, or a workflow that is asking clinicians to do something unreasonable.</div>

---

## The Integrator Layer

- Real breakdown is controlled between domains
- Technology defects get mislabeled as adoption problems
- Process gaps get patched with manual work
- People resistance exposes workflow flaws
- Clean interfaces can still create unsafe behavior

<div class="notes">The integrator layer exists because the real breakdown often lives between domains. A technology problem gets mislabeled as user resistance. A process defect gets hidden by manual work. People resistance exposes a workflow flaw leadership preferred not to see. A technically clean interface creates unsafe behavior because the receiving workflow is wrong. If nobody owns the cross-domain diagnosis, the organization will solve the wrong problem with impressive discipline.</div>

---

## Cross-Domain Failure Pattern

| Observed Problem | Wrong Diagnosis | Better Diagnosis |
|:---|:---|:---|
| Clinicians avoid documentation flow | User resistance | Workflow adds cognitive load |
| Interface is green but data is wrong | No technical issue | Semantic mapping failure |
| Training scores are low | Poor learner effort | System does not match work |
| Compliance is high | Adoption achieved | After-the-fact documentation |

<div class="notes">This table shows how easy it is to misdiagnose failure. If clinicians avoid a documentation flow, the easy answer is resistance. The better answer may be cognitive load, poor timing, bad screen design, or duplicate documentation. If the interface is green but the data is wrong, the easy answer is that there is no technical issue. The better answer is that the technical transport succeeded while the semantic and workflow intent failed.</div>

---

## Failure Management Dashboard

| Layer | Purpose |
|:---|:---|
| Executive Snapshot | Force current leadership decisions |
| Failure Register | Track signals, control action, owner, and status |
| Decision Log | Record stop, change, accept, and defer choices |
| Review Cadence | Match frequency to clinical and operational risk |

<div class="notes">The dashboard is not a status report. A status report tells leaders what happened or what percentage is complete. A failure management dashboard tells leaders what needs control now. The executive snapshot should identify active failures, failure velocity, critical path exposure, and the decision required this cycle. If it does not force a stop, change, accept, defer, or implement decision, it is not governing the implementation.</div>

---

## Healthcare IT Failure Register Fields

- Failure ID and domain
- Clinical risk and patient safety exposure
- Workflow, role, location, and shift affected
- Interface, system component, or data element involved
- Detection signal, control action, owner, and next review time

<div class="notes">A Healthcare IT failure register has to be more specific than a generic issue log. The failure may be isolated to a unit, shift, role, device, interface, order type, report, or data element before it becomes visible at enterprise level. That specificity determines the control response. A generic issue produces generic action; a precise failure record creates the conditions for fast intervention.</div>

---

## Example Failure Register Entry

| Field | Example |
|:---|:---|
| Failure Signal | ACK success with rising result-visibility complaints |
| Scope | ED night shift, chemistry results, EHR inbox |
| Threshold | More than 3 verified complaints in 4 hours |
| Control Owner | Interface lead and ED clinical operations lead |
| Decision Required | Hold expansion, validate mapping, activate manual result check |

<div class="notes">This is the level of specificity that makes the register useful. The signal is not just that users are unhappy. The signal is ACK success with rising result-visibility complaints in a defined scope. The threshold tells the team when governance must act. The owner pairing keeps the technical and clinical sides in the same decision loop. The decision required is explicit, so the register becomes a control instrument rather than a parking lot for issues.</div>

---

## Implementation Cadence

- Map the change surface across PPT and integrator dependencies
- Apply the six control questions to each material element
- Implement controls, fallbacks, and corrective changes
- Operate the dashboard on a risk-weighted cadence
- Run leadership simulations before pressure arrives

<div class="notes">The cadence turns the framework into an operating system. First, map the change surface: Roles, workflows, interfaces, access points, data flows, downtime procedures, reporting obligations, vendors, locations, and shifts. Then apply the six control questions to each material element. The output should be controls, fallbacks, corrective changes, owner assignments, and escalation thresholds. During go-live or high-risk clinical periods, the cadence must tighten because the cost of late detection increases.</div>

---

## Go-Live Control Cadence

- Daily readiness review before activation
- Command center during go-live
- Shift-based signal capture and floor observation
- Interface, identity, and data-quality checks
- Rapid decision huddles and degradation monitoring

<div class="notes">Go-live is not the point where governance relaxes. It is the point where governance has to move closer to the work. A command center is useful, but it is not enough if the signals never leave the floor. You need shift-based capture, floor observation, interface checks, identity checks, data-quality checks, and rapid decision huddles. The operating standard is simple: See the signal, assign authority, make the control decision, and implement the correction while the system is still recoverable.</div>

---

## What This Produces

- Earlier visibility of weak signals
- Faster intervention before failure scales
- Cleaner separation of technical, workflow, and adoption problems
- Better executive decisions under uncertainty
- Safer clinical continuity during implementation

<div class="notes">Used properly, this framework produces practical capabilities. It gives the organization earlier visibility of weak signals. It enables faster intervention before failure scales. It helps leaders separate technical defects from workflow defects and adoption problems. It improves executive decision-making under uncertainty. Most importantly, it protects clinical continuity while the implementation is still being shaped by reality.</div>

---

## Key Takeaways

- Silence is not stability
- Compliance is not adoption
- Availability is not operational success
- Failure must be controlled before it cascades
- Change management is an active control system

<div class="notes">The closing message is simple. Silence is not stability. Compliance is not adoption. Availability is not operational success. Healthcare IT leaders have to stop accepting weak proxies when the actual risk sits in workflow behavior, data meaning, clinical timing, and trust. Failure-aware change management is not about expecting defeat. It is about building an active control system that protects patients, staff, operations, and decision quality while change is underway.</div>

---

## Apply It to One Active Initiative

- **Discussion Prompt:** Where is your current change portfolio most likely to confuse silence with stability?
- **Next Step:** Select one active initiative and build its control dashboard
- **Operating Standard:** Protect continuity, safety, trust, and decision quality

<div class="notes">Apply the framework to one active initiative, not the entire portfolio. Pick the project where silence is most likely being mistaken for stability. Build the control dashboard, define the signals, authorize the owners, and decide what intervention happens when the evidence appears. That is where this framework becomes useful: Not as a theory of change, but as a control discipline for the work that must survive contact with clinical reality.</div>
