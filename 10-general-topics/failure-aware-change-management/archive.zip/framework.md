# Failure-Aware Change Management Framework

## Core Statement

Change management is the systematic identification, containment, and adaptation to failure across people, process, and technology before it compounds into irreversible loss.

## Strategic Reframe

Traditional change frameworks usually begin with an optimistic assumption: adoption is achievable, resistance is the exception, and the implementation plan will hold if communication and training are adequate.

This framework starts from the opposite assumption: failure is the default condition of change, and success must be engineered.

That is not pessimism. It is an operational discipline. Every material change introduces misalignment, friction, and breakdown the moment the plan touches reality. The responsible question is not whether failure will appear. It will. The responsible question is whether the organization has designed the instruments, cadences, owners, and decision rights to see it early enough to act.

In healthcare IT, this is not academic. A failed workflow does not merely inconvenience staff. It creates workarounds. Workarounds create data gaps. Data gaps degrade clinical decisions. By the time the dashboard turns red, the patient safety risk may already be in motion.

## Governing Principles

### 1. Failure Is the Default Condition of Change

Change introduces three predictable failure classes:

- Misalignment: People do not interpret the change the same way.
- Friction: Processes do not fit the physical reality of the work.
- Breakdown: Technology does not behave as expected under real operating conditions.

Initial plans are hypotheses. Execution is where those hypotheses are tested. A mature change system treats failure as a continuous stream of signals during implementation, not as an outcome discovered at the end.

### 2. Detection Must Be Actively Designed

The most consequential failures often make no noise. A clinical champion withdraws. A department manager repeats the new message without conviction. Two systems appear to be available while exchanging subtly incorrect information. A team complies on paper and survives through shadow work.

Passive status reporting will not catch this early enough. Detection requires named owners, explicit signals, scheduled review cadences, frontline listening posts, data quality checks, workflow observation, and escalation paths that allow uncomfortable evidence to surface.

The question that must be asked at the planning level is:

> How will we know something is going wrong before it becomes a crisis?

### 3. Containment Comes Before Scale

An unresolved failure should not be allowed to spread just because the rollout plan says the next site or department is due. Change management must create operational firebreaks:

- Limit feature exposure when technology is unstable.
- Freeze or isolate failing process segments.
- Use controlled deviations when forced compliance would create more risk.
- Deploy targeted clarification loops instead of broad communication blasts.
- Protect the clinical critical path before protecting the project optics.

Speed only matters if the system remains safe enough to absorb it.

### 4. Adaptation Is the Operating Model

Change management is not a control system that enforces a fixed design into existence. It is an adaptive implementation system.

Leaders must continuously update assumptions, adjust rollout sequencing, revise workflows, modify training, reprioritize fixes, and trade speed against stability based on real evidence. The plan is not sacred. Patient safety, service continuity, semantic integrity, and clinician cognitive load are.

### 5. Accountability Must Cross People, Process, and Technology

Most implementation failures are misdiagnosed because organizations inspect people, process, and technology in isolation. A technology issue gets blamed on adoption. A process flaw gets hidden by manual work. A people-resistance pattern exposes a workflow defect that leadership preferred not to see.

The framework, therefore, requires an integrator layer: a deliberate mechanism for examining how people, processes, and technology interact under pressure. This is where the real failure pattern usually lives.

## Operating Model

The framework functions as an organizational immune system:

- Detect threats early.
- Isolate them before they cascade.
- Adapt the implementation based on real-world evidence.
- Strengthen the organization after each failure is understood.

The operating model has four components:

- Philosophy: expect failure.
- Framework: apply the people, process, technology, and integrator overlay.
- Tooling: maintain a failure management dashboard and failure register.
- Capability: train leaders through live simulation and disciplined decision cadence.

## The Six Diagnostic Questions

Every material change element should be interrogated with six questions. These questions apply at the project, workstream, department, workflow, and system-function levels.

1. Success Criteria: What does success look like for this element?
2. Assumptions: What are we assuming must be true for this to work?
3. Expected Failure: Where do we expect this to fail, and what specifically may fail?
4. Detection: How will we first detect the failure, and how will we know the signal is credible?
5. Prevention: What must we do now to reduce the probability or impact of that failure?
6. Response: What will we do when the failure appears?

The output of these questions is not a discussion summary. It must revise the implementation plan to incorporate preventive measures, detection mechanisms, response mechanisms, ownership assignments, and escalation thresholds.

## The PPT Failure Overlay

The people, process, and technology overlay identifies where failure can originate. The integrator layer identifies where failure mutates across domains.

### People: Failure in Alignment and Behavior

People failure occurs when the organization assumes agreement because it has received attendance, acknowledgment, or superficial compliance. In reality, the room may be unconvinced, the informal authority structure may be hostile, or the stated owner may be inactive.

Common failure modes:

- Flying Blind: the project does not know who matters, where they stand, or what authority they hold.
- Influential Opponent: the person others follow is working against the change.
- Owner in Name Only: accountability exists on paper but not in behavior.
- Not Enough Advocates: the right advocates are not present in the right units, shifts, or professional groups.
- Too Many Fence-Sitters: the majority is waiting to see whether the change will survive.
- Resistance Mismanagement: pushback is dismissed, indulged, or escalated inappropriately.
- Stale Situation: The stakeholder map no longer reflects the room.
- Loss of Trust: leaders are no longer believed, even when the message is technically correct.
- Reversion: staff returns to old behaviors under pressure.

Detection signals:

- Declining participation in meetings, training, or readiness activities.
- Increase in side conversations, complaints, or informal escalation.
- Repeated questions that indicate low message absorption.
- Managers are giving inconsistent interpretations of the change.
- Clinical champions are becoming quiet or unavailable.
- Workarounds appearing before go-live or shortly after launch.

Containment actions:

- Run targeted clarification loops with the affected group.
- Use frontline managers as interpreters, not message-forwarders.
- Engage influential opponents directly and early.
- Isolate resistant groups to understand whether the problem is behavioral, operational, or technical.
- Reinforce the local reason for change, not a generic enterprise narrative.

Adaptation moves:

- Adjust the message based on real objections.
- Change incentives or consequences if behavior is not shifting.
- Replace inactive owners with accountable operators.
- Rebuild the advocate network by role, location, shift, and authority level.
- Retrain only after confirming that confusion, usability, and workflow design are not the root cause.

### Process: Failure in Execution Flow

Process failure occurs when the designed workflow does not match how work actually happens. This is common in healthcare because the official process map often omits informal coordination, shift-based constraints, physical movement, unit culture, and the quiet improvisations that keep care delivery functioning.

Common failure modes:

- Current-State Error: the future process is designed against a false picture of today.
- Designed for Ideal Conditions: the workflow works in planning but fails under real workload, staffing, and interruption patterns.
- Stuck Between Old and New: old and new processes run simultaneously until the hybrid becomes the real operating model.
- Missing Informal Work: the change disrupts unofficial practices without replacing the value they provided.
- Champion-Only Success: the process works for early adopters but not for ordinary users.
- Compliance Without Improvement: the process is followed, but outcomes do not improve.
- Process Erosion: the future state degrades after project closure.
- Role Confusion: duplicate ownership, unclear handoffs, or decision paralysis appear.

Detection signals:

- Tasks accumulating at specific workflow stages.
- Exception handling increasing over baseline.
- Staff skipping steps to get the work done.
- Escalations and rework becoming normal.
- Cycle time drifting beyond baseline.
- Compliance numbers looking acceptable while outcome measures stay flat.

Containment actions:

- Freeze or isolate failing process segments.
- Permit controlled deviations where forced compliance would increase risk.
- Run rapid process huddles with actual operators, not only designers.
- Reassign resources to unblock the critical path.
- Separate emergency workaround authorization from permanent process approval.

Adaptation moves:

- Redesign workflows based on observed behavior.
- Remove theoretical steps that do not add control, safety, or value.
- Clarify ownership, handoffs, and decision rights.
- Update SOPs during implementation, not only after post-mortem review.
- Retire old workflows deliberately so the hybrid state does not become permanent.

### Technology: Failure in Systems and Tools

Technology failure occurs when tools are unstable, inaccessible, semantically unreliable, poorly integrated, or misaligned with the work. In clinical environments, the highest-risk technology failure is not the visible outage. It is wrong information delivered through a system that appears to be working.

Common failure modes:

- Wrong System Selected: the platform does not fit how staff actually work.
- Access and Infrastructure Failure: staff cannot reliably access the system where care is delivered.
- Wrong Information, Real Consequences: the system produces unreliable, incomplete, duplicated, delayed, or incorrect data.
- Non-Use: staff avoid the system and complete the work elsewhere.
- No Operational Improvement: the system is live, but the expected improvement does not materialize.
- Decline After Launch: performance, data quality, or user confidence deteriorates over time.
- Integration Fragility: interfaces technically pass messages but fail the semantic or workflow intent.
- Usability-Induced Risk: the interface drives wrong selection, missed documentation, or unsafe cognitive load.

Detection signals:

- Support tickets spike by role, department, location, or workflow.
- Users revert to paper, spreadsheets, chat messages, or manual reconciliation.
- Error rates increase.
- Latency and availability complaints cluster around critical moments of work.
- Data discrepancies appear across systems.
- Interface feeds look technically green while operational users report incorrect results.

Containment actions:

- Roll back, disable, or limit exposure of unstable functionality.
- Establish manual fallback paths with clear activation criteria.
- Prioritize fixes by clinical and operational impact, not by technical severity alone.
- Stand up visible rapid-response support at the point of work.
- Increase reconciliation and data quality monitoring for high-risk interfaces.

Adaptation moves:

- Reprioritize the technical roadmap based on real usage.
- Improve usability where friction is highest.
- Adjust integrations to reflect actual workflow, not just vendor data models.
- Retrain users only after root usability, access, and data quality issues are addressed.
- Strengthen infrastructure where the physical environment is the constraint.

## The Integrator Layer

The integrator layer exists because the real breakdown is often not inside people, process, or technology individually. It is in their interaction.

Cross-domain failure patterns:

- A technology issue is mislabeled as user resistance.
- A process gap is patched with manual work until the system becomes irrelevant.
- People resistance exposes process flaws leadership ignored.
- A clean technical interface creates unsafe operational behavior because the receiving workflow is wrong.
- Training appears to fail because the system is asking clinicians to execute a process that does not fit care delivery.
- Compliance appears high because staff are documenting after the fact while doing the real work elsewhere.

Integrator review questions:

1. Is the observed failure being blamed on the correct domain?
2. What people behavior is being shaped by the process and technology design?
3. What process workaround is compensating for technology or governance weakness?
4. What technology signal looks healthy while operational reality is failing?
5. What clinical or business risk is hidden by headline compliance?
6. Who has authority to make the cross-domain decision?

The integrator layer should be owned by the implementation leadership team, not delegated to a single workstream. No workstream can reliably diagnose the failure pattern if the failure sits outside its own boundary.

## Failure Management Dashboard

The dashboard is not a status report. It is a decision system designed to force visibility of failure.

### Executive Snapshot

The executive view should be short, current, and decision-oriented:

- Overall Change Health: green, yellow, or red based on failure velocity, not completion percentage.
- Top Three Active Failures: tagged by People, Process, Technology, or Integrator.
- Failure Trend: increasing, stable, or decreasing.
- Critical Path at Risk: yes or no.
- Decision Required This Cycle: the one decision leadership must make now.

### Failure Register

Each meaningful failure should be logged in a consistent structure:

- Failure ID: unique identifier.
- Domain: People, Process, Technology, or Integrator.
- Description: plain-language statement of the failure.
- Signal Type: leading signal or lagging signal.
- Severity: low, medium, high, or critical.
- Detection Signal: the specific evidence that triggered attention.
- Impact: clinical, operational, financial, regulatory, reputational, or adoption impact.
- Containment Action: what is being done now to prevent spread.
- Adaptation Decision: what must change in the implementation design.
- Owner: one accountable person.
- Status: open, contained, resolved, or accepted risk.
- Review Date: next decision point.

Example:

- Failure ID: F-017
- Domain: Process
- Description: Approval step creating a three-day delay against a one-day target.
- Signal Type: Lagging
- Severity: Medium
- Detection Signal: Cycle time increased from one day to three days.
- Containment Action: Temporary bypass for low-risk approvals.
- Adaptation Decision: Redesign approval logic using threshold-based auto-approval.
- Owner: Named accountable process owner.
- Status: Contained

### Decision Log

Every review cycle must force explicit leadership choices:

- What are we stopping?
- What are we changing immediately?
- What are we accepting as risk for now?
- What decision is being deferred, and what is the cost of deferral?

No decision is still a decision. In this framework, silence is treated as permission for failure to expand.

## Implementation Cadence

### 1. Map the Change Surface

Break the project into change elements across people, process, technology, and integrator dependencies. For healthcare IT work, this should include clinical roles, operational roles, data flows, interfaces, access points, physical locations, shift patterns, downtime procedures, reporting obligations, and vendor dependencies.

### 2. Apply the Six Diagnostic Questions

Run the six questions against each material change element. Do not stop at risk identification. Force the team to define detection, prevention, response, owner, and decision threshold.

### 3. Update the Implementation Plan

The implementation plan must absorb the framework outputs:

- Preventive measures.
- Detection mechanisms.
- Response mechanisms.
- Escalation paths.
- Manual fallbacks.
- Training modifications.
- Workflow redesign decisions.
- Interface and data quality controls.
- Owner assignments.
- Executive decision points.

### 4. Operate the Dashboard

Review the dashboard weekly for standard projects and more frequently for critical clinical, regulatory, or go-live periods. The purpose is not reporting completeness. The purpose is to surface the few failures that can materially damage adoption, continuity, safety, or trust.

### 5. Run Leadership Simulations

Leaders need practice responding before the real pressure arrives. Simulation should expose them to realistic failure patterns:

- A clinical champion withdraws quietly.
- A dashboard remains green while frontline users report wrong information.
- A process bottleneck forces shadow work.
- A vendor declares an interface stable while semantic mismatches persist.
- A department complies publicly and resists privately.

The simulation objective is not theater. It is decision conditioning: see failure early, act without waiting for certainty, coordinate across domains, and protect the critical path.

## What This Framework Produces

Used properly, the framework produces four organizational capabilities:

- Earlier visibility of weak signals.
- Faster containment of localized failure.
- Better adaptation of the implementation plan to reality.
- Stronger leadership discipline under uncertainty.

The practical outcome is a change environment where leaders stop confusing silence with stability, compliance with adoption, and system availability with operational success.

In a 24/7 clinical environment, that distinction is not philosophical. It is the difference between a system that merely goes live and a system that can be trusted when decisions matter.
